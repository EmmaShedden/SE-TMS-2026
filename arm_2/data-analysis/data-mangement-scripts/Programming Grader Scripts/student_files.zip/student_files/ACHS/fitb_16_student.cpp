switch(animal) {
    case "pig":
        cout << "Oink!" << endl;
        break;
    case "hen":
        cout << "Cluck!" << endl;
        break;
    case "cow":
        cout << "Moo!" << endl;
        break;
    default:
        break;
}