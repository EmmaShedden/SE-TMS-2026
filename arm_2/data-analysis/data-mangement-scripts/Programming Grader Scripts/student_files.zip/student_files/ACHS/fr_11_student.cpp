int factorial(int n){
    int i = n;
    int k = n - 1;
    int ans = 0;

    while(k != 0){
        ans += i * k;        
        i--;
        k--;
    }
    return ans;
}