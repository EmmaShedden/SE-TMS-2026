void swapints(int &a, int &b) {
int temp = a;
int a = b;
int b = temp;
}