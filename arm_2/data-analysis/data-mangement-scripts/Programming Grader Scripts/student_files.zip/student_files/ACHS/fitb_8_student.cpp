for (k = 0; k < 98; k++) {
    cout << "*";
}