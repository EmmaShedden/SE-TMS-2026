int absoluteValue(int num1) {
    
    return abs(num1);
}