bool is_sorted(vector<int> vec){
    for(int i = 1; i < vec.size(); i++){
         if(vec[i] < vec[i-1]){return false;}   
    }
    return true;
}