void countdown(int n){
    for(int i = n; i != -1; i--){
        cout <<  n << " ";
    }
    cout << "liftoff";
}