int cnt;
canPrint = false;
for (int i = 11; i <= 121; i++) {
       for(int j = 0; j < 10; j++){
            
            if(i % j != 0){
                cnt++;
                if(cnt == 9){
                canPrint = true;
                }
            }
   
        }
        if(canPrint){
        cout << i << " " ;
        }//dear god this is a terrible solution
}