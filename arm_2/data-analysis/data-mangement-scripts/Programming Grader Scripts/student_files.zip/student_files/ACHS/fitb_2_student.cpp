addOne (int& x) {
    x++;
}