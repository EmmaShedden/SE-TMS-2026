string shifty(string s, int x){
    for(int i = 0; i < s.length(); i++){
        int newVal = atoi(s[i]) + x;
        s[i] = toString(newVal);
    }
}