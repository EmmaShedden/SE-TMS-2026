double sphere_volume(int r){
    double vol = ((1/3) * 4 * 3.14 * pow(r, 3));
    return vol;
}