int secondGreatest(vector<int> vector_num){
    sort(vector_num.begin(), vector_num.end());
    return vector_num[vector_num.size() - 2]
}