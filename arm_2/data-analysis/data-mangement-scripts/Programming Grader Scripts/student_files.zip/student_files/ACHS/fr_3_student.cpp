if(!onOffSwitch){onOffSwitch = true;}
else{onOffSwitch = false;}