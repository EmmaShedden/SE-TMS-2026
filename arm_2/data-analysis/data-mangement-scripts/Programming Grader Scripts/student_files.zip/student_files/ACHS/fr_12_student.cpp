bool iaPrime(int n){
    int divisior = 2;
    for(int i = 0; i < 9; i++){
        if(n % divisior == 0){return false;}
         divisior++;   
    }
}