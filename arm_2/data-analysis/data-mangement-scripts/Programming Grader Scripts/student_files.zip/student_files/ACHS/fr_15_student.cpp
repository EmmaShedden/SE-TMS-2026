double find_mean(vector<int> array_num){
    int cnt = 0;
    double ans;
    for(int i = 0; i < array_num.size(); i++){
        cnt += array_num[i];
    }
    ans = (cnt / array_num.size());
    return ans;
}