int cnt = total;
while(cnt <= 100){
    cin >> amount;
    cnt + amount;
}