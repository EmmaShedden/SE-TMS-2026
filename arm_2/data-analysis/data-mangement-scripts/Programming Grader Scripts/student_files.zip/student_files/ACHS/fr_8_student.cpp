 bool containsDuplicate(vector[] vec_list){
    unordered_map elements;
    elements.insert(vec_list[0]);
    for(int i = 1; i < vec_list.size(); i++){
        if(elements.find(vec_list[i]) != elements.end()){
            return true;
        }
        else{elements.insert(vec_list[i]);}
    }
    return false;
}