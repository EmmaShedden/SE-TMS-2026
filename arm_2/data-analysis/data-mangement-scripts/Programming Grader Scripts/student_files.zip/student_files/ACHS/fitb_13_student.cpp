int max(int x,int y,int z) {
    if (x > z && x > y) {
        return x;
    } else if (y > z && y > x) {
        return y;
    } else {
        return z;
    }
}