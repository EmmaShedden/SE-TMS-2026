if((modelName == "Extravagant") && ((modelYear <= 2002) && (modelYear >= 1999)){
    cout << "RECALL";
}