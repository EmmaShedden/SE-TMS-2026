int absoluteValue(int num1) {
    // This setup is not possible
    return absoluteValue;
}