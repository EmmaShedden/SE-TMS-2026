double sphere_volume(int r){
    return ((1/3) * 3.14 * static_cast<double>(pow(r, 3)));
}