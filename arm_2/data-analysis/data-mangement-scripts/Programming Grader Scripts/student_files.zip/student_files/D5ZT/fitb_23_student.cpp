int digit_sum(int value) {
    int result = 0;
    while (value > 0) {
        result += value % 10;
        value = ; // This doesn't work because of the previous line?
    }
    return result;
}