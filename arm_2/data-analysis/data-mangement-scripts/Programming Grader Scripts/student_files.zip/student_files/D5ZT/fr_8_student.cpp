bool containsDuplicate(vector<int> vec_list){
    for(int i = 0; i < vec_list.size(); ++i){
        int scannning_for = vec_list[i];
        for(int j = 0; j < vec_list.size(); ++j){
            if(j == i) {continue;} 
            if (scaning_for==vec_list[j]){return true;}
        }
    }
return false;
}