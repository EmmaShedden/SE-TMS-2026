int secondGreatest(vector<int> vector_num){
    if(vector_num.size() == 0) {throw some error}
    if(vector_num.size() == 1) { return vector_num[0]; }
    int max = vector_num[0];
    for(int i = 0; i < vector_num.size(); ++i){
        if(vector_num[i] > max) { max = vector_num[i]; }
    }
    
    for(int i = 0; i < vector_num.size(); ++i){
        if(vector_num[i] == max) { vector_num.remove(vector_num.begin(), i); }
    }
    
    max = vector_num[0];

    for(int i = 0; i < vector_num.size(); ++i){
        if(vector_num[i] > max) { max = vector_num[i]; }
    }
    
    return max;
}