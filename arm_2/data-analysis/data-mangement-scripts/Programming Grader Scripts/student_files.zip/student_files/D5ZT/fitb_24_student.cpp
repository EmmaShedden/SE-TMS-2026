void triangle(int value) {
    for (int i = value; i > 0; i--) {
        for (int j = value; j > 0; --j) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
    return;
}