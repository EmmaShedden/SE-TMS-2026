int exam_score;
cin >> exam_score;
bool isFailing = exam_score - 50; \\ but this doesn't work if they score below 50 bc     
                                                \\ answer becomes negative
if (isFailing) {
    cout << "You failed!" << endl;
} else {
    cout << "You passed!" << endl;
}