int amount = 0, total = 0;

while(cin >> amount && total <= 100){
    total += amount;
}