for (k = 0; k < 97; ++k) {
    cout << "*";
}