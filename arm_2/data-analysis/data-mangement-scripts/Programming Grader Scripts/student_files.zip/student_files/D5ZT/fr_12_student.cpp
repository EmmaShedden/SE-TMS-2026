bool isPrime(int num){
    if(num == 0 || num == 1 || num == 2 || num == 3){return true;}
    if(num % 2 == 0 || num % 3 == 0){return false;}
    // I can't remember the test for primes :(
}