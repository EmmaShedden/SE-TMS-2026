if(modelName == "Extravagant" && (modelYear == 1999 || modelYear == 2000 || modelYear == 2001 || modelYear == 2002)) {
cout << "RECALL" << endl;
}