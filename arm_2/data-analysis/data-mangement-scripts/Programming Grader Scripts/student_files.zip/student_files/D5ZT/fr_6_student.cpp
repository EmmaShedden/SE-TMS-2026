string s;
int x;
for(int i = 0; i < s.size(); ++i){
    s[i] = s[i] + 1;
}