 bool is_sorted(vector<int> values){
    if(value.size() == 0) { throw some error }
    int oneback = value[0];
    for(int i = 0; i < value.size(); ++i){
        if(oneback > value[i]) { return false; }
        else { oneback = value[i]; }
    }
    return true;
}