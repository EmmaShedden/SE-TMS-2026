void countdown(int n){
    for(int n; n > 0; --n){
        cout << n << " ";
    }
    cout << "liftoff!" << endl; \\ gotta flush with endl
}