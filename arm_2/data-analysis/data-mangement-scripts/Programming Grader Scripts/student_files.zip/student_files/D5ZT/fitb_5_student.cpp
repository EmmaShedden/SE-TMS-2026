bool isSenior(int age) {
    if(age >= 65){return true;}
    return false;
}