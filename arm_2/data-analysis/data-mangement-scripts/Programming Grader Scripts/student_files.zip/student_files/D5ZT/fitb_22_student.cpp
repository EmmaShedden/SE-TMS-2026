string reverseString(const string &str) {
    string reversedStr;
    for (int i = 0; i < str.length(); ++i) {
        reversedStr += str[str.length() - i]; // but I fear this will miss the first letter, ie the "a" in "apple" because the loop won't run when i == str.length();
    }
    return reversedStr;
}