for (count = 1; cout <= 40; ++count) {
    cout << count << " ";
}