float sphere_volume(int r) {
    return (4.0 * 3.14 * (r * r * r)) / 3.0;
}