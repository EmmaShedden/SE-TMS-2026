bool is_sorted(vector<int> values) {
    if (values.size() < 2) return true;
    for (int i = 1; i < values.size(); i++) {
        if  (values[i] < values[i - 1]) return false;
    }
    return true;
}