for () {
    cout << "*";
}