void onOffSwitch(bool *toggle) {
    *toggle = !*toggle;
}