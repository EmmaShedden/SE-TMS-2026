int secondGreatest(vector<int> vector_num) {
    int greatest = 0x80000000; // should be negative minimum iirc
    int second_greatest = 0x80000000;
    for (int i = 0; i < vector_num.size(); i++) {
        if (vector_num[i] > greatest) {
            second_greatest = greatest;
            greatest = vector_num[i];
        } else if (vector_num[i] > second_greatest) {
            second_greatest = vector_num[i];
        }
    }
    return second_greatest;
}