 double find_mean(vector<int> array_num) {
    double sum = 0;
    for (int i = 0; i < array_num.size(); i++) {
        sum += array_num[i];
    }
    return sum / array_num.size();
}