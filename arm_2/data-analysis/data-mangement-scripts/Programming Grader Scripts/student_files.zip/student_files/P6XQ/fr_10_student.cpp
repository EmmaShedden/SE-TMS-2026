void countdown(int n) {
    for (int i = n; i > 0; i--) {
        std::cout << i <<  std::endl;
    }
    std::cout << "liftoff!" << std:endl;
}