if (modelYear >= 1999 && modelYear <= 2002 && modelName == "Extravagant") 
    std::cout << "RECALL" << std::endl;