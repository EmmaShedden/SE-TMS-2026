if modelName.equals("Extravagant") {
    for(int i = 1999; i < 2003; i ++) {
        if modelYear == i {
            cout << "RECALL" << endl;
        }
    }
}