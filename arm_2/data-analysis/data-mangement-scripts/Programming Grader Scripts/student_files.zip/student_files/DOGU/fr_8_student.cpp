bool containsDuplicate(vector::int vec_list) {
    for(int i = 0; i < size(vec_list); i++) {
        for(int j = 0; j < size(vec_list); j++) {
            if (vec_list.at(i) == vec_list.at(j) {
                if i != j {
                    return true;
                }
            }
        }
    }    

    return false;
}