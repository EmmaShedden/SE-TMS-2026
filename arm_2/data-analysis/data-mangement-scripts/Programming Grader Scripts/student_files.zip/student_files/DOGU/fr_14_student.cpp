double sphere_volume(int r) {
    double V = (1/3) * 4 * 3.14 * pow(r, 3);
    return V;
}