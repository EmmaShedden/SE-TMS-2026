cpy_s = s;
s = "";
for each c in cpy_s
    c = c + x;
    s += c;

return s;