int absoluteValue(int num1) {
    int absoluteValue = num1;
    if num1 < 0 {
        absoluteValue = absoluteValue * -1;    
    }
    return absoluteValue;
}