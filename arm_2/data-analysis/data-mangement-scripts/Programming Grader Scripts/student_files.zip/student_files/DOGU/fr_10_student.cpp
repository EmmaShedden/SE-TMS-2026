void countdown(int n) {
    for(int i = n; i > 0; i--) {
        cout << i << " ";
    }
    cout << "liftoff!" << endl;
}