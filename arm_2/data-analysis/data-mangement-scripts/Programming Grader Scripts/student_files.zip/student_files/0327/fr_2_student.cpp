if(modelYear <= 2002 && modelYear >= 1999 && modelName == "Extravagant")
    cout << "RECALL";