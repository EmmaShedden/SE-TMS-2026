double find_mean(double[] array_num){
    double sum = 0;
     int count  = 0;
     for(double i : array_num){
            ++count;
            sum += i;
        }
    return sum / count;
}