int exam_score;
cin >> exam_score;
bool isFailing = exam_score < 50;
if (isFailing) {
    cout << "You failed!" << endl;
} else {
    cout << "You passed!" << endl;
}