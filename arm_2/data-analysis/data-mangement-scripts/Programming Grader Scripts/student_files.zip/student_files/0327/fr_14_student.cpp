double sphere_volume(int r){
    return 4 / 3 * 3.14 * pow(r, 3);
}