int N = s.length();
x %= N;
x = N - x;
s = s.substr(x) + s.substr(0, x);