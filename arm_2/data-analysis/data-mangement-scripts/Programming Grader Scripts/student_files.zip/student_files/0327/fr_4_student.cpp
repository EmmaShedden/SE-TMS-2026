bool isPositive(int n){
    if(n > 0) return true;
    return false;
}