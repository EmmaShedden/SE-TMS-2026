bool is_sorted(vector<int> arr){
    int curr = INT_MIN;
    for(int i : arr){
        if(i < curr)
            return false;
        curr = i;
    }   
    return true;
}

