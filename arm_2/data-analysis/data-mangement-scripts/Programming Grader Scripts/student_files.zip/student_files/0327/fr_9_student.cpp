int secondGreatest(vector<int> vector_num){
    assert(vector_num.size() >= 2);
    int greatest = INT_MIN;
    int greatest2 = INT_MIN;
    for(int i: vector_num){
        if(i >= greatest){
            greatest2 = greatest;
             greatest = i;
          }
     }
        return greatest2;
}