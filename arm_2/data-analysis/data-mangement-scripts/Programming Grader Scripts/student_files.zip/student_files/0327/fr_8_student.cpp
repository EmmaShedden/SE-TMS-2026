bool containsDuplicate(vector<int> vec_list){
    sort(vec_list.begin(), vec_list.end());
    for(int i = 1; i < vec_list.size(); i++)
        if(vect_list[i] == vec_list[i-1])
            return true;
    return false;
}