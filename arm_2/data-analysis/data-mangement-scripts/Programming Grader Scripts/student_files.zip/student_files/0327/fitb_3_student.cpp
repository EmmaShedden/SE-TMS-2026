int absoluteValue(int num1) {
    int absoluteValue = num1 >= 0 ? num1 : num1 * -1;
    return absoluteValue;
}