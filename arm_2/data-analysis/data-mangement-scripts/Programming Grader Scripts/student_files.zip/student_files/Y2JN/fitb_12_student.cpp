if (temperature > 98.6) {
    fever =true;
} else {
    fever = false;
}