int amount =0; 
int total =0;
 

while (total <100 ) {
    stdin >> amount; // oops forgot the syntax for that;
    total+=amount
}

