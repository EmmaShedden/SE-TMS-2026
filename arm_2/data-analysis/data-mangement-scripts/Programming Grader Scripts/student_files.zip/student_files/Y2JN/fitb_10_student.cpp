bool notDivisibleByThree(int x) {
    return X%3==1;
}