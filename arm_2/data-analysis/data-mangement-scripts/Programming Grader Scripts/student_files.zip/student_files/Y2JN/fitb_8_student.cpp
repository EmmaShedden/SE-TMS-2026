for (int k=0; k<97; k++) {
    cout << "*";
}