int min (int num1, int num2) {
    return min(num1,num2);
}