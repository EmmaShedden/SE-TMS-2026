double find_mean (int array_num[]){
    int total=0;
    int size= sizeOf(array_num)/ sizeOf(array_num[1]);
    for (int i=0; i<size; i++){
      total= total + array_num[i];  
    }

    return total/size;
}