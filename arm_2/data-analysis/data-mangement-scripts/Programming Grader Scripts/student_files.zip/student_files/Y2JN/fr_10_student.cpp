void countdown(int n){
    for (int i=n; i>1; i--){
        std::cout<< "n  ";
    }
    std::cout<<"liftoff!";
return;
}