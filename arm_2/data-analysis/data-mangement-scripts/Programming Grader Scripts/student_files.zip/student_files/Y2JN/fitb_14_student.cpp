for(int i = 0; i < 3; i++){
    for(int j = 0; j < 5; j++){
        x1[i,j]= x2[i,j];
    }
}