double sphere_volume(int r){
    return  V= (1/3)*4*3.14*r^3;