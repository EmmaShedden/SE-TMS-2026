int digit_sum(int value) {
    int result = 0;
    while (value > 0) {
        result += value % 10;
        value = value - (value%10);
    }
    return result;
}