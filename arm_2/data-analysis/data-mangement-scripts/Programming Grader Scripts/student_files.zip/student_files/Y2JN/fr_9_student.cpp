int secondGreatest(vector <int> vector_num){
    int greatest=INT_MIN; // oops forgot the syntax for this
    int secondGreatest= INT_MIN;
    
    for (int i=0; i< vector_num.size(); i++){
        if (vector_num[i]>greatest){
            greatest=vector_num[i];
        } else if (vector_num[i] > secondGreatest){
            secondGreatest=vector_num[i];
        }
    }
            

    return secondGreatest;

}