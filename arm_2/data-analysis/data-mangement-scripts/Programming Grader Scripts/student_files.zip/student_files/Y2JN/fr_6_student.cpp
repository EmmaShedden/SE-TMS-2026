void shift (String s, int x){
    String alphabet= "abcdefghijklmnopqrstuvwxyz";
        
    for (int i=0; i<s.size(); i++){
        char letter= s[i];
        int alph_ind=27;
        for(int j=0; j<alphabet.size(); j++){
            if (alphabet[j]==letter){
                if (j+x> alphabet.size()){
                    x=j+x - alphabet.size();
                }
                s[i]=alphabet[j+x];
            }
         }            
       }
    return;
}