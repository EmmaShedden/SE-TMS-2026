bool isSenior(int age) {
    return age>65;
}