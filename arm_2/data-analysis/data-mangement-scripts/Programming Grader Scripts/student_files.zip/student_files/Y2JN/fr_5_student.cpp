bool is_sorted (vector<int> values){
    int prev= values[0];    
    for (int i=1; i< values.size(); i++){
        if (values[i]<prev) {
            return false;
        }
      }
       return true;

 }        