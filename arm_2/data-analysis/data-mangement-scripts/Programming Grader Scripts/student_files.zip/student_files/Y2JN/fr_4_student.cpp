bool isPositive(int n){
    return n>0;
}