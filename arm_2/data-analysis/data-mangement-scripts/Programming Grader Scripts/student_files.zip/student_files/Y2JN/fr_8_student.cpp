bool containsDuplicate(vector<int> vec_list){
    std::sort(vec_list.begin(), vec_list.end()); // hopefully that is the right syntax
    for (int i=0; i<vec_list.size()-2; i++){
        if (vec_list(i)== vec_list(i+1)){
            return true;
        }
       }
    return false;
}