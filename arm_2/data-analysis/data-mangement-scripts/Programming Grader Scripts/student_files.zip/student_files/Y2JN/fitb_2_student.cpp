void addOne (int& x) {
    x++;
}