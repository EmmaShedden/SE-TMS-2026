float sphere_volume(int r){
    float pi = 3.14;
    float r_cubed = r ** 3;
    float numeric = 4.0f / 3.0f;
    return pi * r_cubed * numeric;
}