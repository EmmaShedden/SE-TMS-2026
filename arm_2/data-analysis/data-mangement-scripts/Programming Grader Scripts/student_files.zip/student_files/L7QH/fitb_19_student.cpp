string capitalize_first_letter(string text) {
    for (int x = 0; x < text.length; ++x){
        if (x == 0 || text[x - 1] == ' '){
             text[x] = toupper(text[x]); 
            } 
        } 
     return text; 
}