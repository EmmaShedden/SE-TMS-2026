int absoluteValue(int num1) {
    absoluteValue = math.abs(num1);
    return absoluteValue;
}