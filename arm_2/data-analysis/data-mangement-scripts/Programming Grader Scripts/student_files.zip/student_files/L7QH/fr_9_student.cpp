int secondGreatest(vector<int> vector_num){
    sort(vector_num.begin(), vector_num.end());
    int secondGreatest = vector_num[vector_num.size() - 2];
    return secondGreatest;
}
