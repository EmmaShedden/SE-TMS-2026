while (total <= 100){
        std::cin >> amount;
        total += amount;
}