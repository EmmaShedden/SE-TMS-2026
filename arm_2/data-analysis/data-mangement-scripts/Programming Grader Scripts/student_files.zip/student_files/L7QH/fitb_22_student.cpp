string reverseString(const string &str) {
    string reversedStr;
    for (int i = 0; i < str.length(); ++i) {
        reversedStr += str[str.length() - 1 - i];
    }
    return reversedStr;
}