int power(int x, int y) {
    if (y == 0) {
        return 1;
    } else if (y == 1) {
        return x;
    }

    int tmp = power(x, y);
    tmp = tmp * tmp;
    if (y % 2 == 1) {
        return x * tmp;
    } else {
        return tmp;
    }
}