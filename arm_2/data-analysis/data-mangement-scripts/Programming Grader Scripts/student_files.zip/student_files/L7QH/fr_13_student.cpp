bool isEven(int n){
    return !(n%2);
}