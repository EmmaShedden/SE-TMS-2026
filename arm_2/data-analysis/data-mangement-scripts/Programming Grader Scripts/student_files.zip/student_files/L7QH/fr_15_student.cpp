float find_mean(vector<int> array_num){
    float mean = 0;
    for (int i = 0; i < array_num.size(); ++i){
        mean += array_num[i];
    }
    return mean / array_num.size();
}