bool isPalindrome(string str) {
    int left = 0;
    int right = str.length() - 1;
    while (left < right) {
        if (str[left++] != str[right--]) {
            return false;
        }
    }
    return true;
}