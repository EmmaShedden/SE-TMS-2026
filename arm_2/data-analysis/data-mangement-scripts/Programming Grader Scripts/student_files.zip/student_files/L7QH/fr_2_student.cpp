if (modeYear >= 1999 && modelYear <= 2002 &&
    modelName == "Extravagant"){
    cout << "RECALL";
}