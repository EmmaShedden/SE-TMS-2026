bool is_sorted(vector<int> input){
    for (int i = 0; i < input.size() - 1; ++i){
        if (input[i]  > input[i + 1]){
             return false;
        }
    }
    return true;
}