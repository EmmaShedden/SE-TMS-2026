int multiply_two_nums(int x, int y) {
    if (y == 0){ 
        return 0;}
    if (y > 0) {
        return (x + multiply_two_nums(x, y - 1));}
    if (y < 0) {
        return (x - multiply_two_nums(x, y + 1));}
}