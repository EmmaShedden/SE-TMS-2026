bool containsDuplicate(vector<int> vec_list){
    unordered_map<int, bool> cnt;
    for (int i = 0; i < vec_list.size(); ++i){
        if (cnt[vec[i]] == false){
            cnt[vec[i]] = true;
        } else{
            return true;
        }
    }
    return false;
}