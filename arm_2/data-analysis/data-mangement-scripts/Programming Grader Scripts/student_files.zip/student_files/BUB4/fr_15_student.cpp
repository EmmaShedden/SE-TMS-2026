int find_mean(int* array_num){
    float total = 0;
    for(int x = 0; x < array_num.size(); x++){
        total += array_num[x];
    }
    return total / array_num.size();