bool is_sorted(vector<int> my_vector) {
    if(my_vector.size() <= 1) return true;
    for(int i = 1; i < my_vector.size(); i++) {
        if (my_vector[i] < my_vector[i-1]) return false;
    }
    return true;
}