int max(int x,int y,int z) {
    if (x > z && x > y) {
        return x;
    } else if (y > x && y > z) {
        return y;
    } else {
        return z;
    }
}