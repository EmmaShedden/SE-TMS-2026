void countdown(int cd) {
    for (int i = cd; i > 0; i++){
        cout << i << " ";
    }
    cout << "liftoff!";
}