int factorial(int n) {
    int factl = 1;
    for(int x = n; x>0; x--){
        factl *= n;
    }
    return factl;
}