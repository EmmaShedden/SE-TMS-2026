if (modelYear >= 1999 && modelYear <= 2002) {
    if (modelName == "Extravagant") cout << "RECALL";
}