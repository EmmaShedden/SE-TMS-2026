 int sphere_volume(int r) {
   int volume = 4 * r * r * r * 3.14;
   volume = volume / 3;
   return volume;
} 