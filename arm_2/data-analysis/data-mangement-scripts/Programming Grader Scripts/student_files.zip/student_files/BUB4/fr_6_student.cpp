for (int i = 0; i < s.len(); i++) {
    if (s[i] + x >= 'z' + 1) s[i] -= 26;
    s[i] += x;
}