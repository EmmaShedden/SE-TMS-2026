bool containsDuplicate(vecotr<int> vec_list) {
    for(int i = 0; i < vec_list.size(); i++) {
        for(int j = i+1; j < vec_list.size(); j++) {
            if(vec_list[i] == vec_list[j]) return true;
        }
    }
    return false;
}