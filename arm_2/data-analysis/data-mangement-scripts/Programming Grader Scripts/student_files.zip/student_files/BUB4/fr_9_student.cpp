int secondGreatest(vecotr<int> vector_num) {
    int largest = vector_num[0];
    int second = 0;
    if(vector_num.size() > 1 && largest > vector_num[1]) {
        second = vector_num[1];
    }
    for(int i = 1; i < vector_num.size(); i++) {
        if(vector_num[i] > largest) {
            second = largest;
            largest = vector_num[i];
        }
    }
    return second;
}