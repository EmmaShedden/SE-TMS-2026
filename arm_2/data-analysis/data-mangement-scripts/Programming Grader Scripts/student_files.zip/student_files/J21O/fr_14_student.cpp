double sphere_volume(const int &r){
    double volume = (1/3)*4*3.14159 * (r*r*r);
    return volume;

}