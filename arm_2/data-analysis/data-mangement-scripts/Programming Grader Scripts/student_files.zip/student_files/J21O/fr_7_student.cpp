while(total<=100){
   cin << stoi(amount);    
   total += amount;

}