bool isSenior(int age) {
    bool is_greater = (age>=65);
    return is_greater;
}