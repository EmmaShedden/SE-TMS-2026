double find_mean(array< int> array_num){
  double sum_elts = 0;
   for (size_t i = 0; i < array_num.size(); i++){
      sum_elts += array_num[i];

   }
   return sum_elts/array_num.size();

}