bool isPrime(int n){
    //prime number: divisible by itself and one
    assert(n>=0);
    if(n % 2 !== 0 && n % n == 0 && n%1 == n){
        return true;
    }
    return false;
}