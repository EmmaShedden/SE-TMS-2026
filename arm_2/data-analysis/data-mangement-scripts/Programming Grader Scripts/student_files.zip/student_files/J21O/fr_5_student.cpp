bool is_sorted(vector< int> vector){
   for (size_t i = 0; i < vector.size(); i++){
      if(vector[i+1] < vector[i]){
          return false;
       }
   }
   return true;

}