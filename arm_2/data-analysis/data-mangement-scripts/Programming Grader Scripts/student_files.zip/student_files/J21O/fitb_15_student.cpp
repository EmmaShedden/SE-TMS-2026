max = x[0][0];
for(i = 0; i < 6; i++){
    for(j = 0; j < 8; j++){
        if(x[i][j]>max){
            max = x[i][j];
        }
    }
}