if (onOffSwitch){
    onOffSwitch = false;

} else{
    onOffSwitch = true;
}