void shift(string &s, int x){
    for (int i = 0; i < s.length; i++){
        s += x;
    }
}