for (count = 1; count <=40; count--) {
    cout << count << " ";
}