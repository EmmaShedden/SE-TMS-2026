void recall(int modelYear, string modelName){    
    string name = "Extravagant";
    if(modelName == name && modelYear >= 1999 && modelYear <=2002){
        cout << "RECALL";
    }
}