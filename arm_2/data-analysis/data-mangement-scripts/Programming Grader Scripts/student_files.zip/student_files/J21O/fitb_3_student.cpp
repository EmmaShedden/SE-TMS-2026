int absoluteValue(int num1) {
    if (num>=0){
        return num1;
    } else {
        return (num1+(num1*2));
    }
    
}