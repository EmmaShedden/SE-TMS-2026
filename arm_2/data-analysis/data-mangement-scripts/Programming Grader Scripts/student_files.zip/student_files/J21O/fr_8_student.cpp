bool containsDuplicate(const vector < int > &vec_list){
    assert(vec_list.size() >= 2);    

    int previous_elemet = vec_list[0];
    for(int i = 1; i < vec_list.size(); i++){
        if(vec_list[i] == previous_element){
            return true;
        }
        previous_element = vec_list[i];
    }
    return false;
}