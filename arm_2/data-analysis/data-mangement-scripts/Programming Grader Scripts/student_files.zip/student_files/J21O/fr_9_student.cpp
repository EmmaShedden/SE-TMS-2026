int secondGreatest(vector< int > vector_num){
   assert(vector_num.size() >= 2);
   int greatest = vector_num[0];
   int second_greatest = vector_num[1];

   for(size_t i = 2; i < vector_num.size(); i++){
      if(vector_num[i] > greatest && second_greatest > vector_num[i]){
          int temp = greatest;
          greatest = vector_num[i];
          second_greatest = temp;
      }
   }
   return second_greatest;
}