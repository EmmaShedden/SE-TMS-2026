bool isPositive(const int &n){
    bool is_positive = (n >=0);
    return is_positive;

}