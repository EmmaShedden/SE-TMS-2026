 bool isEven(const int &n){
    return n%2== 0;

}