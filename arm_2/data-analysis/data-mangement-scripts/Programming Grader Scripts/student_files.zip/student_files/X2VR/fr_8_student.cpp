 bool containsDuplicate(vector<int> vec_list) {
    sort(vec_list.begin(), vec_list.end());
    for (int i = 0; i < vec_list.size() - 1; ++i) {
        if (vec_list[i] == vec_list[i + 1]) {
        return true;}
    }
return false;
}