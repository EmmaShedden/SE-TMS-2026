int exam_score;
cin >> exam_score;
bool isFailing = false;
if (exam_score < 50) { isFalling = true}
if (isFailing) {
    cout << "You failed!" << endl;
} else {
    cout << "You passed!" << endl;
}