void triangle(int value) {
    for (int i = value; i > 0; i--) {
        for (int j = 0; j < value; ++j) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
    return;
}