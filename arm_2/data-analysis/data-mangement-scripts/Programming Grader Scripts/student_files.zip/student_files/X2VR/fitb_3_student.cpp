int absoluteValue(int num1) {
    int absoluteValue = abs(num1);
    return absoluteValue;
}