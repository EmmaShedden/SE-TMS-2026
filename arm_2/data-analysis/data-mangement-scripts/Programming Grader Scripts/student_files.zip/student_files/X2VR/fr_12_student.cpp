bool isPrime(int n ) {
for (int i = 2; i <=n - 1 ;++i) {
    if (n % i == 0) { // divisible by another num not itself or 1
        return false;    
    }
}
return true;
}