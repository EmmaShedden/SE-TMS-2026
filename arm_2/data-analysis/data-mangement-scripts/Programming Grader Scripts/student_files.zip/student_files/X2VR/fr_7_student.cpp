while (total <= 100) {
cin >> amount;
total += amount;
}