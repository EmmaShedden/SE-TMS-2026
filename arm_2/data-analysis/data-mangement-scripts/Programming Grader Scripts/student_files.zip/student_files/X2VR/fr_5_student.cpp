bool is_sorted(vector<int> nums) {
for (int i = 0; i < nums.size() - 1; ++i) {
    if (nums[i]  > nums[i + 1]) {
           return false; 
}
}
return true;
}



// 1 3 5 6 7 