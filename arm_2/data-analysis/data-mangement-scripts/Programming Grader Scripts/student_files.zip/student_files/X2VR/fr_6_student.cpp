for (int i = 0; i < s.size(); ++i) {
    s[i] = s[i] - '0' + x; // i think this converts s[i] to the char shifted by x?
}
