int find_mean(vector<int> array_nums) {
    int sum = 0;
    for (int i = 0; i < array_nums.size(); ++i) {
    sum += array_nums[i];
}
    return sum / array_nums.size()
}