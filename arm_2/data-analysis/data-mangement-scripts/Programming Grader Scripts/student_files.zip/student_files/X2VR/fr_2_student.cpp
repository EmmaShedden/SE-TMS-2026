if(modelYear >= 1999 && modelYear <= 2002 && modelName.find("Extravagant") {
    cout << "RECALL";
}