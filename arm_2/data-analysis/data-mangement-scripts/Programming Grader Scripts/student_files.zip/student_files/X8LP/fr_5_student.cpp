bool is_sorted(vector<int> vect) {
    for (int i = 1; i < vect.length(); i++) {
        if (vect[i] > vect[i - 1]) {
            return true;
        }
    }
    return false;
}