int absoluteValue(int num1) {
    int absoluteValue = num1;
    if (absoluteValue < 0) {
        absoluteValue *= -1;
    }
    return absoluteValue;
}