 double sphere_volume(int r) {
    return (1/3)4 * 3.14 * r * r * r;
}