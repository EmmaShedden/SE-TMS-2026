int secondGreatest(vector<int> vector_num) {
    int greatest = vector_num[0];
    int second_greatest = vector_num[0];
    for (int i = 1; i < vector_num.length(); i++) {
        if  (greatest < vector_num[i]) {
            second_greatest = greatest;
            greatest = vector_num[i];
        }
        else if (vector_num[i] > second_greatest) {
            second_greatest = vector_num[i];
        }
    }
    return second_greatest;
} 
            