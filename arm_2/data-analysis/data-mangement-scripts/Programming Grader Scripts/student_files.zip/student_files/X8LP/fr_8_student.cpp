bool containsDuplicate(vector<int> vec_list) {
    int size = vec_list.size();
    if (size == 1 || size == 0) {
        return false;
    }
    
    vector<int> stores[size];
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < stores.size(); j++) {
            if (vec_list[i] == stores[j]) {
                return true;
            }
        }
        stores[i] = vec_list[i];
    }    
}