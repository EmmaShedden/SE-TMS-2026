int find_mean(arr array_num[]) {
    int mean = 0;
    for (int i = 0; i < array_num.length(); i++) {
        mean += array_num[i];
    }
    return mean / array_num.length();
}