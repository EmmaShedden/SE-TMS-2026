void letter_shift(string s, int x) {
    for (int i = 0; i < s.length(); i++) {
        int temp = int(s[i]);
        temp += x;
        s[i] = char(temp);
    // UGH i know there'll be a bug when shifting 
    // by big values of x but i don't know ASCII 
    // well enough ;_;
    }
}