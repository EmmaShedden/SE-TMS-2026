bool isPrime (int n) {
    // not sure how to mathematically determine if
    // a number is prime! oops
    return false;
}