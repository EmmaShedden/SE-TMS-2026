int secondGreatest(vector vector_num) {
    sort(vector_num);
    return vector_num[length(vector_num) - 2];
}