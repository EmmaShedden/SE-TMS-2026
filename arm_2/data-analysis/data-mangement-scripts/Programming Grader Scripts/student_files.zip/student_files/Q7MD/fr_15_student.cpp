float find_mean(arr[n] array_num) {
    int sum = 0;     
    for (int i = 0; i < n; ++i){
        sum += arr[i];
    }
    return sum / n;
}    