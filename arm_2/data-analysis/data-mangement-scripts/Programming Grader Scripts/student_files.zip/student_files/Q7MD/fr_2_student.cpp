if (modelName == "Extravagant" && 1999 < modelYear && modelYear < 2002) {
    cout << "RECALL";
}