for (; k < 98; ++k) {
    cout << "*";
}