bool containsDuplicate(vector<int> vec_list) {
    sort(vec_list);
    for (int i = 0; i < vec_list.length() - 1; ++i) {
        if  (vec_list[i] == vec_list[i+1]){
            return true;
         }
    }
    return false;
}