void triangle(int value) {
    for (int i = value; i > 0; i--) {
        for (int k = i; k > i - 1; k--) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
    return;
}