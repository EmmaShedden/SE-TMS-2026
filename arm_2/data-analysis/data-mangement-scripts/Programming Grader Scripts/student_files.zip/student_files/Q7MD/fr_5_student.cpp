bool is_sorted(vector<int> vec) {
    for (int i = 0; i < vec.length() - 1; ++i) {
        if (vec[i] > vec[i + 1]) {
            return false;
        }
    }
    return true;
}