while (cin || total < 100) {
    cin >> amount;     
    total += amount; 
}