int secondGreatest(std::vector<int> vector_num) {
    if (vector_num.size() < 2) {
        return NaN;
    }

    int first = vector_num[0]
    int sec = vector_num[1]
    if (first < sec) {
        int tmp = first;
        first = sec;
        sec = tmp;
    }    

    for (int i = 2; i < vector_num.size(); ++i) {
        if (vector_num[i] >= first) {
            sec = first;
            first = vector_num[i];
        }
        else if (vector_num[i] > sec) {
            sec = vector_num[i];
        }
    }

    return sec;
}