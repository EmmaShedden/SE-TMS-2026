void countdown(int n) {
    for(n; n >= 1; --n) {
        cout << (n) << " ";
    }
    print("liftoff!")
}