bool notDivisibleByThree(int x) {
    return 0 != (x % 3);
}