void recall(int modelYear, string modelName) {
    if(modelYear >= 1999 && modelYear <= 2002 && modelName == "Extravagant") {
        print("RECALL")
    }
}