string shiftString(string s, int x) {
    string alph = "abcdefghijklmnopqrstuvwxyz";
    int strLen = s.length();
    if(s.length() == 0) {
        return s; 
    }
    string first = s[0];
    int pos = -1;
    for(int i = 0; i < 26; ++i) {
        if(first == alph[i]) {
            pos = i;
            break;
        }
    }
    if(pos == -1) {
        return s;
    }
    string retStr = "";
    for(int k = 1; k <= strLen; ++k) {
        retStr = retStr + alph[(pos + k + x) % 26];
    }
    return retStr;
}