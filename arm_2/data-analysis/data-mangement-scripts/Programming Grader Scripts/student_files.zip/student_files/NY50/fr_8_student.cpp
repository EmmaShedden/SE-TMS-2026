bool containsDuplicate(vector<int> vec_list) {
    set<int> set_list;
    for(int i = 0; i < vec_list; ++i) {
        set_list.add(vec_list[i]);
    }
    return set_list.size() != vec_list.size();
}