double find_mean(int[] array_num){
    len = sizeof(array_num) / sizeof(array_num[0]);
    sum = 0.0;
    for (int i = 0; i < len; ++i) {
        sum += array_num[i];
    }

    return sum / len;
}