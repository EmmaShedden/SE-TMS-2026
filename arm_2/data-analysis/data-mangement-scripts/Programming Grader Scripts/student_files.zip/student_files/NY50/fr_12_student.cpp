bool isPrime(int n) {
    for(int i = 2; i < n; ++i) {
        if((n / double(i)) % 1 == 0) {
            return False;
        }
    }
    return True;
}