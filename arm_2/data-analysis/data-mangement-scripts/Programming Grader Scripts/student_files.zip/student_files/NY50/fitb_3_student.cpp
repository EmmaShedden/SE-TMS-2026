int absoluteValue(int num1) {
    int absoluteValue = num1;
    if(num1 < 0) {
        absoluteValue = num1 * -1;
    }
    return absoluteValue;
}