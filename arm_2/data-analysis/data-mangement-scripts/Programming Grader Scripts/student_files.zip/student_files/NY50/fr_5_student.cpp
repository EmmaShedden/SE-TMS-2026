bool is_sorted(std::vector<int> vals) {
    int prev = vals[0]
    for (int i = 1; i < vals.size(); ++i) {
        if (vals[i] < prev) {
            return false;
        }
        prev = vals[i];
    }

    return true;
}