for (k = k % 1; k < 97; ++k) {
    cout << "*";
}