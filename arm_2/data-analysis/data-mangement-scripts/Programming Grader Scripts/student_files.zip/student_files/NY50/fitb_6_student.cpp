for (count = 1 + (count % 1); count < 41; ++count) {
    cout << count << " ";
}