double sphere_volume(int r) {
    return (1/3) * 4 * pi * (r*r*r);
}