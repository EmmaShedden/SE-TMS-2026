bool change switch(bool onOffSwitch) {
    if (onOffSwitch == false) {
        onOffSwitch = true;
    } else if (onOffSwitch == true) {
        onOffSwitch = false;
    }
}