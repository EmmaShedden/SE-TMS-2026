bool is_sorted(vector<int> vec) {
    for (int i = 0; i < vec.size(); ++i) { 
    if (vec[i] < vec[i + 1]) { 
        return true; 
    } else { 
        return false; 
    }
}