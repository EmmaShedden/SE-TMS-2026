void function1(int amount, int total) {
    while (total <= 100) {
        cin >> amount;
        total += amount;
    }
}