addOne (int& x) {
    x += 1;
}