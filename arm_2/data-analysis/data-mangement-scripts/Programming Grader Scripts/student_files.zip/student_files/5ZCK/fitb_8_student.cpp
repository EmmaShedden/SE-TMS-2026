for (int i = 0; i < 97; ++i) {
    cout << "*";
}