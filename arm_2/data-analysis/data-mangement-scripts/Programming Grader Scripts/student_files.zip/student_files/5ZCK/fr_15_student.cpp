int find_mean(int arr[] array_num) {
    int total = 0;
    int size = array_num.size();
    for (int i = 0; i < size; ++i) {
        total += array_num[i];
    }
    return total / size;
}