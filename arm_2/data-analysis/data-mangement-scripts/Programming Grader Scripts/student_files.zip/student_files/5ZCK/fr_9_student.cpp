int secondGreatest(vector<int> vector_num) {
    vector_num.sort();
    vector_num.pop_back();
    return vector_num(vector_num.size() - 1);
}