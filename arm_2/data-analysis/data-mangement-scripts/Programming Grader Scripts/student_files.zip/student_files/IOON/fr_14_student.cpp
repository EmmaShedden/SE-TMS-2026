 double sphereVolume(int r){
    return (1.0/3) * 4 * 3.14 * r * r * r;
}