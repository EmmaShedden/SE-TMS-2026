bool is_sorted(vector<int> vals){
    for(int i = 1; i < vals.size(); i++){
        if(vals[i] < vals[i-1]){
            return false;
        }
    }
    return true;
}