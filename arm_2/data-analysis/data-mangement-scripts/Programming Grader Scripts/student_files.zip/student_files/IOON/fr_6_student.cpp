string shift(string s, int x){
    string newS = ""
    for(int i = 0; i < s.size(); i++){
        newS  += s[i] + x;
    return newS;
}
s = shift(s);