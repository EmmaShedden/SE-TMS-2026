 double find_mean(vector<int> array_num){
    double sum = 0;
    for(int i : array_num){
        sum += i;
    }
    return sum / array_num.size();
}