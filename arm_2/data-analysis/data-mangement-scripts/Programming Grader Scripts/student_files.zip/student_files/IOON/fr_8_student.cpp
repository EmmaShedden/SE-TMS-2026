bool containsDuplicate(vector<int> vec_list){
    unordered_set<int> contained;
    for(int i : vec_list){
        if(contained.contains(i)){
            return true;
        }
        contained.insert(i);
    }
    return false;
}