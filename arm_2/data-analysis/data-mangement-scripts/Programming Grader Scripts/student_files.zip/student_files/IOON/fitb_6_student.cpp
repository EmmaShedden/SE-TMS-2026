for (int count = 1; i < 41; i++) {
    cout << count << " ";
}