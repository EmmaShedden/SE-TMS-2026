int secondGreatest(vector<int> vector_num){
    int greatest = INT_MIN;
    int second_greatest = INT_MIN;
    for(int i : vector_num){
        if(i > greatest){
            second_greatest = greatest;
            greatest = i;
        }
        else if( i > second_greatest){
            second_greatest = i
        }
    }
    return second_greatest;
}