if(modelYear >= 1999 && modelYear <= 2002 && modelName == "Extraveagant"){
    cout << "RECALL";
}