void countdown(int n){
    while(n > 0){
        cout << n << " ";
    }
    cout << "liftoff!";
}
