if (match(modelYear,modelName))
    std::cout <<"RECALL";

// match(int modelYear, string modelName) return true if match the recall details