void countdown(int n){
    for (int i=n; i>=0; i--){
        std::cout << i << " ";
        if (i==1)
            std::cout<< "liftoff!";
    }
}