string capitalize_first_letter(string text) {
    for (int i=0; i<text.size();i++){
        if (x == 0 || text[x - 1] == ' '){
             text[x] = toupper(text[x]); 
            } 
        } 
     return text; 
}