float sphere_volumn(int r){
    return 4 * 3.14 * r * r * r / 3;
}