void addOne (int& x) {
    x+=1;
}