 double find_mean(vector<int> array_num){
    double n=array_num.size();
    double sum=0;    
    for (int num:array_num)
        sum+=num;
    return sum/n;
}