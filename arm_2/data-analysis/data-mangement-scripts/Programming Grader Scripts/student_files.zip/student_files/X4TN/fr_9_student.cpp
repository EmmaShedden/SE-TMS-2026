 int secondGreatest(vector<int> vector_num){
    assert vector_num.size()>1;
    int max=max(vector_num[0],vector_num[1]);
    int sec_max=min(vector_num[0],vector_num[1]);
    for (int num : vector_num){
        if (num>max){
            sec_max=max;
            max=num;
        } else if(num>sec_max){
            sec_max=num;
        }
    }
    return sec_max;
}