int absoluteValue(int num1) {
    if (num1<0) num1=-num1;
    return absoluteValue;
}