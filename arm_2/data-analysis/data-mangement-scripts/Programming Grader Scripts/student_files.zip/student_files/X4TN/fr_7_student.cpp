% int amount=0, total=0;
while (total<=100){
    cin >> amount;
    total += amount;
}