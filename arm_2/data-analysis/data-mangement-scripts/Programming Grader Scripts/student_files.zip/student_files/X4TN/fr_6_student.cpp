for (int i=0; i<s.size(); i++)
    s[i]=s[i]+x;