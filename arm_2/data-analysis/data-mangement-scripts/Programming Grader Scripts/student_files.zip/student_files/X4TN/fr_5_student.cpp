bool is_sorted(vector<int> values){
    if (values.empty()) return true;
    int prev = values[0];
    for (int v:values){
        if (v<prev) return false;
        prev = v;
    }
}