bool notDivisibleByThree(int x) {
    return (x%3!=0);
}