bool containsDuplicate(vector<int> vec_list){
    unordered_set<int> appear;
    for (int v : vec_list){
        if (!appear.contain(v))
            appear.insert(v);
        else
            return true;
    }
    return false;
}