#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

bool switch_bool(bool onOffSwitch) {
    
    #include "fr_3_student.cpp"

    return onOffSwitch;
}

int main() {

    if (switch_bool(true) != false) {
        return 1;
    }
    if (switch_bool(false) != true) {
        return 1;
    }

    return 0;
}
