#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fr_3_student.cpp"

int main() {

    bool input = true;

    if (onOffSwitch(input) != false || input != false) {
        return 1;
    }

    input = false;
    if (onOffSwitch(input) != true || input != true) {
        return 1;
    }

    return 0;
}
