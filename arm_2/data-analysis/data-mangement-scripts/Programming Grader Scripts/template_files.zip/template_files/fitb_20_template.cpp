#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_20_student.cpp"

int main() {

    if (power(2, 4) != 16) {
        return 1;
    }
    if (power(10, 3) != 1000) {
        return 1;
    }
    if (power(1, 15) != 1) {
        return 1;
    }
    if (power(3, 12) != 531441) {
        return 1;
    }


    return 0;
}
