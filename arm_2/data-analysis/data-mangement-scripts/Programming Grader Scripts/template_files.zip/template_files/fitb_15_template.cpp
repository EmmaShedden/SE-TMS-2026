#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

int main() {

int x[6][8] = {
  { 1, 2, 3, 4, 5, 6, 7, 8},
  { 1, 2, 3, 4, 5, 6, 7, 8},
  { 1, 2, 3, 4, 5, 6, 7, 8},
  { 1, 2, 3, 100, 5, 6, 7, 8},
  { 1, 2, 3, 4, 5, 6, 7, 8},
  { 1, 2, 3, 4, 5, 6, 7, 8},
};


int max = -1;
int i = -2;
int j = -3;

#include "fitb_15_student.cpp"


if (max != 100) {
    return 1;
}


    return 0;
}
