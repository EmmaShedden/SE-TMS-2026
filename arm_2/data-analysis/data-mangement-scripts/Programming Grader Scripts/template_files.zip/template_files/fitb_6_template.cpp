#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

int main() {

    int count = 0;

#include "fitb_6_student.cpp"

    return 0;
}
