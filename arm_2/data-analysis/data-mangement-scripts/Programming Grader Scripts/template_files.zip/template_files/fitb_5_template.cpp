#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_5_student.cpp"

int main() {

    if (isSenior(64) != false) {
        return 1;
    }
    if (isSenior(65) != true) {
        return 1;
    }
    if (isSenior(66) != true) {
        return 1;
    }


    return 0;
}
