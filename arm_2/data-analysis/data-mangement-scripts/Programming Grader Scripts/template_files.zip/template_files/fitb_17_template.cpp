#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_17_student.cpp"

int main() {

    if (fibonacci(2) != 1) {
        return 1;
    }
    if (fibonacci(8) != 21) {
        return 1;
    }


    return 0;
}


