#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;


int main() {

    int k = 4;
    int a[12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

#include "fitb_11_student.cpp"

    if (a[k + 1] != 9) {
        return 1;
    }

    return 0;
}
