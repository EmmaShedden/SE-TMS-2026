#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_3_student.cpp"

int main() {

    if (absoluteValue(-2) != 2) {
        return 1;
    }
    if (absoluteValue(0) != 0) {
        return 1;
    }
    if (absoluteValue(1) != 1) {
        return 1;
    }


    return 0;
}
