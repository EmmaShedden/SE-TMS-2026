#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_24_student.cpp"

int main() {

    triangle(3);

    return 0;
}
