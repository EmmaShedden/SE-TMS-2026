#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_7_student.cpp"

int main() {

    if (min(2,3) != 2) {
        return 1;
    }
    if (min(2,1) != 1) {
        return 1;
    }
    if (min(1,1) != 1) {
        return 1;
    }


    return 0;
}




