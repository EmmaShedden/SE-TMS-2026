#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;


int main() {

int x1[3][5] = {
  { 1, 2, 3, 4, 5 },
  { 6, 7, 8, 9, 10 },
  { -1, -2, -3, -4, -5},
};

int x2[3][5] = {
  { 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0 },
  { 0, 0, 0, 0, 0 },
};

int x12[3][5] = {
  { 1, 2, 3, 4, 5 },
  { 6, 7, 8, 9, 10 },
  { -1, -2, -3, -4, -5},
};


#include "fitb_14_student.cpp"



for(int i = 0; i < 3; i++){
    for(int j = 0; j < 5; j++){
        if (x2[i][j] != x12[i][j]) {
            return 1;
        }
    }
}


    return 0;
}
