#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <vector>
#include <cmath>


using namespace std;



#include "fr_12_student.cpp"



int main() {

    if (isPrime(8) != false) {
        return 1;
    }

    if (isPrime(11) != true) {
        return 1;
    }


    return 0;
}
