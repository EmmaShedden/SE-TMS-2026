#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fr_6_student.cpp"

int main() {

    if (plusOne("ab", 1) != "bc") {
        return 1;
    }

    if (plusOne("ab", 2) != "cd") {
        return 1;
    }

    if (plusOne("ab", 3) != "de") {
        return 1;
    }

    return 0;
}