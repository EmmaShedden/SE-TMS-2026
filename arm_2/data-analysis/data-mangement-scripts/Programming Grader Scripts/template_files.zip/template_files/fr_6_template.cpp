#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

string shift(string s, int x){
    #include "fr_6_student.cpp"

    return s;
}

int main() {

    if (shift("ab", 1) != "bc") {
        return 1;
    }

    if (shift("ab", 2) != "cd") {
        return 1;
    }

    if (shift("ab", 3) != "de") {
        return 1;
    }

    return 0;
}

