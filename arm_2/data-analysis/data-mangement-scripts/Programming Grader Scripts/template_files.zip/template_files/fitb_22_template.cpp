#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_22_student.cpp"

int main() {

    if (reverseString("a") != "a") {
        return 1;
    }
    if (reverseString("abcde")  != "edcba") {
        return 1;
    }


    return 0;
}
