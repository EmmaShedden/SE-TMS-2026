#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <vector>

using namespace std;



#include "fr_9_student.cpp"



int main() {

    vector<int> v = {0, 1, 1, 1};
    if (secondGreatest(v) != 0) {
        return 1;
    }

    v = {1, 2, 3, 4};
    if (secondGreatest(v) != 3) {
        return 1;
    }

    v = {4, 3, 2, 4};
    if (secondGreatest(v) != 3) {
        return 1;
    }
    return 0;
}

