#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_2_student.cpp"

int main() {
    int a = 0;
    addOne(a);
    if (a != 1) {
        return 1;
    }
    a = 1;
    addOne(a);
    if (a != 2) {
        return 1;
    }


    return 0;
}