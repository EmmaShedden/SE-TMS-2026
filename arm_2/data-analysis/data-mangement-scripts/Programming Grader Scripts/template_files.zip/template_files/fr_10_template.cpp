#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <vector>

using namespace std;



#include "fr_10_student.cpp"



int main() {

    countdown(5);

    return 0;
}


