#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_23_student.cpp"

int main() {

    if (digit_sum(1) != 1) {
        return 1;
    }
    if (digit_sum(123) != 6) {
        return 1;
    }


    return 0;
}

