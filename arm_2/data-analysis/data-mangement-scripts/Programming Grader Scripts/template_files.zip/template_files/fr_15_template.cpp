#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <vector>

using namespace std;



#include "fr_15_student.cpp"



int main() {

    int nums[5] = {0, 0, 0, 0, 0};
    if (find_mean(nums) != 0) {
        return 1;
    }

    int nums2[5] = {1, 2, 3, 4, 5};
    if (find_mean(nums2) != 3) {
        return 1;
    }

    return 0;
}
