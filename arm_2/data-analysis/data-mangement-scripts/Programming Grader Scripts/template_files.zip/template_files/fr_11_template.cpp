#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <vector>

using namespace std;



#include "fr_11_student.cpp"



int main() {

    if (factorial(1) != 1) {
        return 1;
    }

    if (factorial(4) != 24) {
        return 1;
    }


    return 0;
}
