#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;


bool f(float temperature) {

bool fever = false;

#include "fitb_12_student.cpp"

return fever;
}

int main() {

    if (f(98.5) != false) {
        return 1;
    }
    if (f(98.6) != false) {
        return 1;
    }
    if (f(98.5) != false) {
        return 1;
    }


    return 0;
}
