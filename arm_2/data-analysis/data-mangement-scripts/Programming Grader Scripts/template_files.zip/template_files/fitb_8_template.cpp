#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

int main() {

int k = 100;

#include "fitb_8_student.cpp"

    return 0;
}
