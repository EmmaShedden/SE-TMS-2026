#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_10_student.cpp"

int main() {

    if (notDivisibleByThree(0) != false) {
        return 1;
    }
    if (notDivisibleByThree(1) != true) {
        return 1;
    }
    if (notDivisibleByThree(2) != true) {
        return 1;
    }
    if (notDivisibleByThree(3) != false) {
        return 1;
    }

    return 0;
}

