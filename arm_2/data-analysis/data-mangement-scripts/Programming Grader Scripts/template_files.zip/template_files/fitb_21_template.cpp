#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_21_student.cpp"

int main() {

    if (multiply_two_nums(1, -1) != -1) {
        return 1;
    }
    if (multiply_two_nums(0, -4)  != 0) {
        return 1;
    }
    if (multiply_two_nums(4, -5) != -20) {
        return 1;
    }


    return 0;
}

