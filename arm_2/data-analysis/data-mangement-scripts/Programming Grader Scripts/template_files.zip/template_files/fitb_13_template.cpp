#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_13_student.cpp"

int main() {

    if (max(1,2,3) != 3) {
        return 1;
    }
    if (max(2,3,1) != 3) {
        return 1;
    }
    if (max(3,1,2) != 3) {
        return 1;
    }
    if (max(4,3,4) != 4) {
        return 1;
    }


    return 0;
}
