#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;


void sound(string animal){
    
    #include "fitb_16_student.cpp"

}


int main() {

    sound("cow")

    return 0;
}
