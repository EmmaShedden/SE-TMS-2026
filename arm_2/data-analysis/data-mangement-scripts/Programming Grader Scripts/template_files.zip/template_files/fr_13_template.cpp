#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <vector>

using namespace std;



#include "fr_13_student.cpp"



int main() {

    if (isEven(6) != true) {
        return 1;
    }

    if (isEven(7) != false) {
        return 1;
    }


    return 0;
}

