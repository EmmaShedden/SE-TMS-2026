#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_19_student.cpp"

int main() {

    if (capitalize_first_letter("my name is") != "My Name Is") {
        return 1;
    }
    if (capitalize_first_letter("a") != "A") {
        return 1;
    }
    if (capitalize_first_letter(" HeLLo earth ") != " HeLLo Earth ") {
        return 1;
    }


    return 0;
}