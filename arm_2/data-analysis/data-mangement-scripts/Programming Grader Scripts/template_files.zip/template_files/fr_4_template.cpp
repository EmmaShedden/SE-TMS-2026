#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fr_4_student.cpp"

int main() {

    int input = 1;
    if (isPositive(input) != true) {
        return 1;
    }

    input = 25;
    if (isPositive(input) != true) {
        return 1;
    }

    input = -1;
    if (isPositive(input) != false) {
        return 1;
    }

    return 0;
}