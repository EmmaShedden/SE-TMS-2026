#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <vector>

using namespace std;

#include "fr_5_student.cpp"

int main() {

    vector<int> v = {1, 1, 1, 1};
    if (is_sorted(v) != true) {
        return 1;
    }

    v = {1, 2, 3, 4};
    if (is_sorted(v) != true) {
        return 1;
    }

    v = {4, 3, 2, 1};
    if (is_sorted(v) != false) {
        return 1;
    }

    return 0;
}

