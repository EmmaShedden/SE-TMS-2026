#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

int main() {

#include "fitb_4_student.cpp"

    return 0;
}
