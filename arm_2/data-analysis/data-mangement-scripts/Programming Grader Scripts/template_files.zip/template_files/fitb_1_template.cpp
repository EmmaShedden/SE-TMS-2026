#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_1_student.cpp"

int main() {
    int a = 1;
    int b = 2;
    swapints(a,b);
    if (a != 2 || b != 1) {
        return 1;
    }

    a = -7;
    b = 9;
    swapints(a,b);
    if (a != 9 || b != -7) {
        return 1;
    }

    return 0;
}
