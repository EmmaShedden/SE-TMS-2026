#include <iostream>
#include <stdio.h> 
#include <stdlib.h>

using namespace std;

#include "fitb_18_student.cpp"

int main() {

    if (isPalindrome("a") != true) {
        return 1;
    }
    if (isPalindrome("aaaaaaaaaaaa") != true) {
        return 1;
    }
    if (isPalindrome("wow") != true) {
        return 1;
    }
    if (isPalindrome("hi") != false) {
        return 1;
    }
    if (isPalindrome("helloworld") != false) {
        return 1;
    }


    return 0;
}